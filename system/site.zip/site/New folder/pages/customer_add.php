<?php 
session_start();
require('../dist/includes/dbcon.php');
//require('model/customer_functions.php');
	$branch=$_SESSION['branch'];
	$salutation =$_POST['salutation'];
	$salutation_2 =$_POST['salutation_2'];
	$address = $_POST['address'];
	$address_2 = $_POST['address_2'];
	$city =$_POST['city'];
	$state =$_POST['state'];
	$zipcode = $_POST['zipcode'];
	$country = $_POST['country'];
	$firstname =$_POST['firstname'];
	$lastname =$_POST['lastname'];
	$email = $_POST['email'];
	$prayerpartner = $_POST['prayerpartner'];
	$firstname_2 =$_POST['firstname_2'];
	$lastname_2 =$_POST['lastname_2'];
	$email_2 = $_POST['email_2'];
	$prayerpartner_2 = $_POST['prayerpartner_2'];
	$firstname_3 =$_POST['firstname_3'];
	$lastname_3 =$_POST['lastname_3'];
	$email_3 = $_POST['email_3'];
	$prayerpartner_3 = $_POST['prayerpartner_3'];
	$firstname_4 =$_POST['firstname_4'];
	$lastname_4 =$_POST['lastname_4'];
	$email_4 = $_POST['email_4'];
	$prayerpartner_4 = $_POST['prayerpartner_4'];
	$notes = $_POST['notes'];
	$annual = $_POST['annual'];
	
	//var_dump($_POST);die();
	
	//Add a New Customer
	//Create the data array
	/* $data = array(
		
		'salutation' => $salutation,
		'salutation_2' => $salutation_2,
		'address' =>$address,
		'address_2' =>$address_2,
		'city' =>$city,
		'state' =>$state,
		'zipcode' =>$zipcode,
		'country'=>$country,
		'firstname' =>$firstname,
		'lastname' =>$lastname,
		'email'=>$email,
		'prayerpartner' =>$prayerpartner,
		'firstname_2' =>$firstname_2,
		'lastname_2' =>$lastname_2,
		'email_2' =>$email_2,
		'prayerpartner_2' =>$prayerpartner_2,
		'firstname_3' =>$prayerpartner_3,
		'lastname_3' =>$lastname_4,
		'email_3' =>$email,
		'prayerpartner_3' =>$prayerpartner_3,
		'firstname_4' =>$firstname_4,
		'lastname_4' =>$lastname_4,
		'email_4' =>$email_4,
		'prayerpartner_4' =>$prayerpartner_4,
		'notes' =>$notes,
		'annual' =>$annual
		
	);
	
	$result = addCustomer($con,$data);
	if($result){
		$status = "Contact Added Successfully.";
	}else{
		$status = "Error while adding contact.";
	}
	
	die(); */
	
	
	
	$query2=mysqli_query($con,"select * from contact where email='$email'")or die(mysqli_error($con));
		$count=mysqli_num_rows($query2);

		if ($count>0)
		{
			echo "<script type='text/javascript'>alert('Contact already exist!');</script>";
			echo "<script>document.location='cust_new.php'</script>";  
		}
		else
		{	
			
			mysqli_query($con,"INSERT INTO contact(salutation,salutation_2,address,address_2,city,state,zipcode,country,firstname,lastname,email,prayerpartner,firstname_2,lastname_2,email_2,prayerpartner_2,firstname_3,lastname_3,email_3,prayerpartner_3,firstname_4,lastname_4,email_4,prayerpartner_4,notes,annual) 
				VALUES('$salutation','$salutation_2','$address','$address_2','$city','$state','$zipcode','$country','$firstname','$lastname','$email','$prayerpartner','$firstname_2','$lastname_2','$email_2','$prayerpartner_2','$firstname_3','$lastname_3','$email_3','$prayerpartner_3','$firstname_4','$lastname_4','$email_4','$prayerpartner_4','$notes','$annual')")or die(mysqli_error($con));

			$id=mysqli_insert_id($con);
			//$_SESSION['cid']=$id;
			//echo "<script type='text/javascript'>alert('Successfully added new contact!');</script>";
			echo "<script>document.location='customer.php?cid=$id'</script>";  
		}
?>