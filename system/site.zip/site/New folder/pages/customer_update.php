<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;

require('../dist/includes/dbcon.php');
	$id = $_POST['id'];
	$salutation =$_POST['salutation'];
	$salutation_2 =$_POST['salutation_2'];
	$address = $_POST['address'];
	$address_2 = $_POST['address_2'];
	$city =$_POST['city'];
	$state =$_POST['state'];
	$zipcode = $_POST['zipcode'];
	$country = $_POST['country'];
	$firstname =$_POST['firstname'];
	$lastname =$_POST['lastname'];
	$email = $_POST['email'];
	$prayerpartner = $_POST['prayerpartner'];
	$firstname_2 =$_POST['firstname_2'];
	$lastname_2 =$_POST['lastname_2'];
	$email_2 = $_POST['email_2'];
	$prayerpartner_2 = $_POST['prayerpartner_2'];
	$firstname_3 =$_POST['firstname_3'];
	$lastname_3 =$_POST['lastname_3'];
	$email_3 = $_POST['email_3'];
	$prayerpartner_3 = $_POST['prayerpartner_3'];
	$firstname_4 =$_POST['firstname_4'];
	$lastname_4 =$_POST['lastname_4'];
	$email_4 = $_POST['email_4'];
	$prayerpartner_4 = $_POST['prayerpartner_4'];
	$notes = $_POST['notes'];
	$annual = $_POST['annual'];
	
	mysqli_query($con,"update contact set salutation='$salutation',salutation_2='$salutation_2',address='$address',address_2='$address_2',city='$city',state='$state',zipcode='$zipcode',country='$country',firstname='$firstname',lastname='$lastname',email='$email',prayerpartner='$prayerpartner',firstname_2='$firstname_2',lastname_2='$lastname_2',email_2='$email_2',prayerpartner_2='$prayerpartner_2',firstname_3='$firstname_3',lastname_3='$lastname_3',email_3='$email_3',prayerpartner_3='$prayerpartner_3',firstname_4='$firstname_4',lastname_4='$lastname_4',email_4='$email_4',prayerpartner_4='$prayerpartner_4',notes='$notes',annual='$annual' where id_code='$id'")or die(mysqli_error(con));
	
	echo "<script type='text/javascript'>alert('Successfully updated contact details!');</script>";
	echo "<script>document.location='home.php'</script>";  

	
?>
