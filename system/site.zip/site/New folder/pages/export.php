<?php  
  
include "export_config.php";
 
$data = new Connection();
$conn = new mysqli($data->dbHost, $data->dbUsername, $data->dbPassword);  
mysqli_select_db($conn, $data->dbName);  
 
$setSql = "SELECT firstname,lastname,email,firstname_2,lastname_2,email_2 FROM contact";  
$setRec = mysqli_query($conn, $setSql); 
 
$columnHeader = '';  
$columnHeader = "First Name" . "\t" . "Last Name" . "\t" . "Email" . "\t" . "First Name_2" . "\t" . "Last Name_2" . "\t" . "Email_2" . "\t" . "";  
  
$setData = '';  
  
while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=Export_To_Excel.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  
  
echo ucwords($columnHeader) . "\n" . $setData . "\n";  
  
?>