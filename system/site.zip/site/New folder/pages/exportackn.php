<?php  
  
include "export_config.php";
 
$data = new Connection();
$conn = new mysqli($data->dbHost, $data->dbUsername, $data->dbPassword);  
mysqli_select_db($conn, $data->dbName);  
 
$setSql = "SELECT salutation, address, email, amount, category, donation_type, dateofcheck, dateforacknowledge from contact natural join donation";  
$setRec = mysqli_query($conn, $setSql); 
 
$columnHeader = '';  
$columnHeader = "Salutation" . "\t" . "Address" . "\t" . " Email address" . "\t" . "Amount" . "\t" . "Category" . "\t" . "Donanation Type" . "\t" . "Date of Check" . "\t" . "Date Acknowledge" . "\t" .  "";  
  
$setData = '';  
  
while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=Export_To_Excel.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  
  
echo ucwords($columnHeader) . "\n" . $setData . "\n";  
  
?>