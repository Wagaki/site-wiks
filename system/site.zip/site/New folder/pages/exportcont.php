<?php  
  
include "export_config.php";
 
$data = new Connection();
$conn = new mysqli($data->dbHost, $data->dbUsername, $data->dbPassword);  
mysqli_select_db($conn, $data->dbName);  
 
$setSql = "SELECT * FROM contact";  
$setRec = mysqli_query($conn, $setSql); 
 
$columnHeader = '';  
$columnHeader = "Id_code" . "\t" . "Salutation" . "\t" . "Salutation_2" . "\t" . "Address" . "\t" . "Address_2" . "\t" . "City" . "\t" . "State" . "\t" .  "Zip Code" . "\t" . "Country" . "\t" . "First Name" . "\t" . "Last Name" . "\t" . "Email" . "\t" . "PrayerPartner" . "\t" . "First Name_2" . "\t" .  "Last Name_2" . "\t" . "Email_2" . "\t" . "PrayerPartner_2" . "\t" . "First Name_3" . "\t" . "Last Name_3" . "\t" . "Email_3" . "\t" . "PrayerPartner_3" . "\t" .  "First Name_4" . "\t" . "Last Name_4" . "\t" . "Email_4" . "\t" . "PrayerPartner_4" . "\t" . "Notes" . "\t" . "Annual" . "\t" .   "";  
  
$setData = '';  
  
while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=Export_To_Excel.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  
  
echo ucwords($columnHeader) . "\n" . $setData . "\n";  
  
?>