<?php 
session_start();

require('../dist/includes/dbcon.php');
	$salutation = $_POST['salutation'];
	$address = $_POST['address'];
	$email = $_POST['email'];
	$amount = $_POST['amount'];
	$category = $_POST['category'];
	$donation_type = $_POST['donation_type'];
	$check_no= $_POST['check_no'];
	$dateofcheck = $_POST['dateofcheck'];
	$dateofdeposit= $_POST['dateofdeposit'];
	$paypal_fee = $_POST['paypal_fee'];
	$notes= $_POST['notes'];
	$lastname= $_POST['lastname'];
	

			mysqli_query($con,"INSERT INTO donation(salutation,address,email,amount,category,donation_type,check_no,dateofcheck,dateofdeposit,paypal_fee,notes,lastname)
			VALUES('$salutation','$address','$email','$amount','$category','$donation_type','$check_no','$dateofcheck','$dateofdeposit','$paypal_fee','$notes','$lastname')")or die(mysqli_error($con));

			echo "<script type='text/javascript'>alert('Successfully added new donation!');</script>";
					  echo "<script>document.location='product.php'</script>";  
		
?>