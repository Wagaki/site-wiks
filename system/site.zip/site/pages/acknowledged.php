<?php
      include('../dist/includes/dbcon.php');
$id = $_GET['id'];

$date = date("D d-M-Y");

mysqli_query($con,"UPDATE donation SET dateforacknowledge='Yes' WHERE id_no = $id")or die(mysqli_error(con));
	
	echo "<script>
		\$(\"#row-$id\").fadeOut();
		\$(\"#yes-$id\").text('Yes');
	</script>";
?>