<?php
include('model/crud.php');		
$conn = dbconnect();

if ($conn) {


		if (isset($_GET['cat'])){
			$category = $_GET['cat'];

			$sql = "SELECT SUM(amount) AS total FROM donation WHERE category = \"$category\"";
			$results = fetchData($conn,$sql);
						
			if ($results) {
				$results = $results[0];
				$total_by_cat = $results['total'];

				$total_by_date = number_format($total_by_cat,2,'.',',');
				echo $total_by_date;
							
			}
		}
							
		if (isset($_GET['day']) && isset($_GET['month']) && isset($_GET['year'])){
			$dateofdeposit = $_GET['month']."/".$_GET['day']."/".$_GET['year'];
			
			$sql = "SELECT SUM(amount) AS total FROM donation WHERE dateofdeposit = \"$dateofdeposit\"";
			$results = fetchData($conn,$sql);
						
			if ($results) {
				$results = $results[0];
				$total_by_date = $results['total'];

				$total_by_date = number_format($total_by_date,2,'.',',');
				echo $total_by_date;						
			}
		}
} else {
	echo "Error while connecting...";
}

?>