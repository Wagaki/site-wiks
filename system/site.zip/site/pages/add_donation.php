<?php session_start();
//if(empty($_SESSION['id'])):
//endif;
include('../dist/includes/dbcon.php');
  
    if (isset($_POST['cid'])){
      $id = $_POST['cid'];
      
      $donor = mysqli_query($con,"SELECT salutation,lastname,address,address_2,city,state,zipcode FROM contact WHERE id_code = '$id'") or die(mysqli_error());
      
      $donor = mysqli_fetch_array($donor);
    }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Deposit | <?php include('../dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="../plugins/select2/select2.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
    folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
    <style>
      .disabled {
        pointer-events: none;
        background-color: #efefef;
      }
    </style>
  </head>
  <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
  <body class="hold-transition skin-<?php echo $_SESSION['skin'];?> layout-top-nav">
    <div class="wrapper">
      <?php include('../dist/includes/header.php');
      
      ?>
      <!-- Full Width Column -->
      <div class="content-wrapper">
        <div class="container">
          <!-- Content Header (Page header) -->
          <section class="content-header">
            <h1>
            <a class="btn btn-lg btn-warning" href="stockin.php">Back</a>
            
            </h1>
            <ol class="breadcrumb">
              <li><a href="home.php"><i class="fa fa-dashboard"></i> Home</a></li>
              <li><a href="cust_new.php"><i class="fa fa-dashboard"></i> Contact</a></li>
            </ol>
          </section>
          <!-- Main content -->
          <section class="content">
            <div class="row">
              <div class="col-md-12">
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title"><b>ADD DEPOSIT</h3></b>
                  </div>
                  <div class="box-body">
                    <!-- Date range -->
                    <form method="post" action="product_add.php" id='add_donation_form' enctype="multipart/form-data" class="form-horizontal">
                      <div class="row">
                        <div class="col-md-4">
                          <label for="date">Donor Id</label>
                          <div class="input-group col-md-12">
                            <div class="input-group col-sm-12">
                              <input type="text" class="form-control pull-right" id="id_code" name="id_code" readonly value="<?=$id?>">
                              </div><!-- /.input group -->
                              </div><!-- /.form group -->
                            </div>
                            
                            <div class="col-md-4">
                              <label for="date">Salutation</label>
                              <div class="input-group col-md-12">
                                <div class="input-group col-sm-12">
                                  <input type="text" class="form-control pull-right" id="salutation" name="salutation" readonly value="<?=$donor['salutation']?>">
                                  </div><!-- /.input group -->
                                  </div><!-- /.form group -->
                                </div>
                                
                                
                                <div class="col-md-4">
                                  <label for="date">Amount</label>
                                  <div class="input-group col-md-12">
                                    <input type="text" class="form-control pull-right" id="amount" name="amount" placeholder required>
                                    </div><!-- /.input group -->
                                    </div><!-- /.form group -->
                                    </div><!--row-->
                                    <div class="row">
                                      <div class="col-md-4">
                                        <label for="date">Category</label>
                                        <div class="input-group col-md-12">
                                          <select class="form-control select2" id='category' style="width: 100%;" name="category">
                                          <option value="" disabled selected></option>

                                           <?php
                                            $query2=mysqli_query($con,"select * from category")or die(mysqli_error());
                                            while($row2=mysqli_fetch_array($query2)){
                                            ?>
                                            <option value="<?php echo $row2['cat_name'];?>"><?php echo $row2['cat_name'];?></option>
                                            <?php }?>
                                          </select>
                                          </div><!-- /.input group -->
                                        </div>
                                        <div class="col-md-4">
                                          <label for="date">Donation Type</label>
                                          <div class="input-group col-md-12">
                                            <select onchange="checkDonType()" class="form-control select2" id='donation_type' style="width: 100%;"         name="donation_type">
                                          <option value="" disabled selected></option>
                                              <?php
                                              $query2=mysqli_query($con,"select * from donationtype")or die(mysqli_error());
                                              while($row2=mysqli_fetch_array($query2)){
                                              ?>
                                              <option value="<?php echo $row2['don_name'];?>"><?php echo $row2['don_name'];?></option>
                                              <?php }?>
                                            </select>
                                          </div>
                                        </div>

                                        <div class="col-md-4">
                                          <label for="date">Address</label>
                                          <div class="input-group col-md-12">
                                          <input disabled type="text" class="form-control pull-right" id="address" name="address" value="<?=str_replace(",,", ",", ucwords($donor['address'].",".$donor['address_2'].",".$donor['city']." ".$donor['state']." - ".$donor['zipcode']))?>" >
                                          </div><!-- /.input group -->
                                        </div><!-- /.form group -->
                                        
                                      </div>
                                      <div class="row">
                                        <div class="col-md-4">
                                          <label for="date">Check_No</label>
                                          <div class="input-group col-md-12">
                                            <input type="text" class="form-control pull-right" id="check_no" name="check_no" placeholder>
                                            </div><!-- /.input group -->
                                          </div>
                                          <div class="col-md-4">
                                            <label for="date">Date of Donation(Check)</label>
                                            <div class="input-group col-md-12">
                                              <input type="date" class="form-control pull-right" id="dateofcheck" name="dateofcheck">
                                              </div><!-- /.input group -->
                                            </div>
                                            
                                            </div><!--row-->
                                            <div class="row">
                                              <div class="col-md-4">
                                                <label for="date">Date of Deposit</label>
                                                <div class="input-group col-md-12">
                                                  <input type="date" class="form-control pull-right" id="dateofdeposit" name="dateofdeposit" placeholder>
                                                  </div><!-- /.input group -->
                                                </div>
                                                
                                                
                                                  </div><!--row-->
                                                  <div class="row">
                                                    <div class="col-md-4">
                                                      <label for="date">Notes</label>
                                                      <div class="input-group col-md-12">
                                                        <input type="text" class="form-control pull-right" id="notes" name="notes" placeholder>
                                                        </div><!-- /.input group -->
                                                      </div>
                                                      <div class="col-md-4">
                                                        <label for="date">Lastname</label>
                                                        <div class="input-group col-md-12">
                                                          <input type="text" class="form-control pull-right" id="lastname" name="lastname" readonly value="<?=$donor['lastname']?>">
                                                          </div><!-- /.input group -->
                                                        </div>
                                                        </div><!--row-->
                                                        <div class="row">
                                                          
                                                          
                                                        </div>
                                                        
                                                        <div class="col-md-12">
                                                          <div class="col-md-12">
                                                            <button class="btn btn-lg btn-primary pull-right" id="daterange-btn" name="">Submit</button>
                                                          </div>
                                                        </div>
                                                        
                                                      </form>
                                                      
                                                      
                                                      </div><!-- /.box-body -->
                                                      </div><!-- /.box -->
                                                    </div>
                                                    
                                                    
                                                    
                                                    </section><!-- /.content -->
                                                    </div><!-- /.container -->
                                                    </div><!-- /.content-wrapper -->
                                                    <?php include('../dist/includes/footer.php');?>
                                                    </div><!-- ./wrapper -->
                                                    <!-- jQuery 2.1.4 -->
                                                    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
                                                    <!-- Bootstrap 3.3.5 -->
                                                    <script src="../bootstrap/js/bootstrap.min.js"></script>
                                                    <script src="../plugins/select2/select2.full.min.js"></script>
                                                    <!-- SlimScroll -->
                                                    <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
                                                    <!-- FastClick -->
                                                    <script src="../plugins/fastclick/fastclick.min.js"></script>
                                                    <!-- AdminLTE App -->
                                                    <script src="../dist/js/app.min.js"></script>
                                                    <!-- AdminLTE for demo purposes -->
                                                    <script src="../dist/js/demo.js"></script>
                                                    <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
                                                    <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
                                                    
                                                    <script>
                                                    $(function () {
                                                    $("#example1").DataTable();
                                                    $('#example2').DataTable({
                                                    "paging": true,
                                                    "lengthChange": false,
                                                    "searching": false,
                                                    "ordering": true,
                                                    "info": true,
                                                    "autoWidth": false
                                                    });
                                                    });
                                                    $('#add_donation_form').submit(function(e){

                                                       var donType = document.getElementById('donation_type').value;

                                                       if (donType == 'Check') {
                                                          if(!validateCheck()){                                                          
                                                            return false;                                                          
                                                          }
                                                       } else if (donType == 'Paypal') {
                                                          if (!validateFee()) {
                                                            return false;
                                                          }
                                                       } 

                                                       if ($('#dateofdeposit').val() == '') {
                                                          if (donType == 'Paypal' || donType == 'In Kind'|| donType == 'PayPal Giving Fund'||donType == 'Credit Card') {

                                                          } else {
                                                            alert('Enter Date of Deposit');
                                                            return false;
                                                          }
                                                       }
                                                   	
                                                    });
                                                    
	         function validateCheck() {
	            var checkNo = document.getElementById('check_no').value;
              var dateofcheck = $('#dateofcheck').val();
	             if (checkNo.length == 0) {
	               alert('Enter Check Number');
	               return false;

	             } else if(dateofcheck == '') {
                alert('Enter date of Check');
	               return false;

	             } else {
                return true;
              }
	        }
	                                                    	                                                    
	        function validateFee() {
							var fee= document.getElementById('paypal_fee').value;
							if (fee.length == 0) {
    							alert('Please enter Paypal Fee.');
    							return false;

							} else {
							   fee = eval(fee);

                if ((fee <= 0 )) {
                  alert('Paypal fee MUST be greater than 0!');
                  return false;

                } else {
                  return true;
                }
							}
	
					}

          function checkDonType() {            
              var donType = document.getElementById('donation_type').value;

              if (donType == 'Paypal') {
                $('#check_no').addClass('disabled');
                $('#dateofcheck').removeClass('disabled');
                $('#paypal_fee').removeClass('disabled');
                $('#amount').removeClass('disabled');
                $('#dateofdeposit').addClass('disabled');

              } else if (donType == 'Check') {

                $('#check_no').removeClass('disabled');
                $('#dateofcheck').removeClass('disabled');
                $('#paypal_fee').addClass('disabled');
                $('#amount').removeClass('disabled');
                $('#dateofdeposit').removeClass('disabled');
                $('#paypal_fee').val(0);

            } else if (donType == 'In Kind') {

                $('#check_no').addClass('disabled');
                $('#dateofcheck').removeClass('disabled');
                $('#paypal_fee').addClass('disabled');
                $('#amount').addClass('disabled');
                $('#dateofdeposit').addClass('disabled');
                $('#paypal_fee').val(0);
           
           } else if (donType == 'Cash') {

                $('#check_no').addClass('disabled');
                $('#dateofcheck').removeClass('disabled');
                $('#paypal_fee').addClass('disabled');
                $('#amount').removeClass('disabled');
                $('#dateofdeposit').removeClass('disabled');
                $('#paypal_fee').val(0);

            } else if (donType == 'PayPal Giving Fund') {

                $('#check_no').addClass('disabled');
                $('#dateofcheck').removeClass('disabled');
                $('#paypal_fee').addClass('disabled');
                $('#amount').removeClass('disabled');
                $('#dateofdeposit').addClass('disabled');
                $('#paypal_fee').val(0);

           } else if (donType == 'Wire') {

                $('#check_no').addClass('disabled');
                $('#dateofcheck').removeClass('disabled');
                $('#paypal_fee').addClass('disabled');
                $('#amount').removeClass('disabled');
                $('#dateofdeposit').removeClass('disabled');
                $('#paypal_fee').val(0);

         
           } else if (donType == 'Credit Card') {

                $('#check_no').addClass('disabled');
                $('#dateofcheck').removeClass('disabled');
                $('#paypal_fee').removeClass('disabled');
                $('#amount').removeClass('disabled');
                $('#dateofdeposit').addClass('disabled');
                
           } else if (donType == 'United Way') {

                $('#check_no').addClass('disabled');
                $('#dateofcheck').removeClass('disabled');
                $('#paypal_fee').addClass('disabled');
                $('#amount').removeClass('disabled');
                $('#dateofdeposit').removeClass('disabled');
                $('#paypal_fee').val(0);

              } else {

                $('#check_no').addClass('disabled');
                $('#dateofcheck').addClass('disabled');
                $('#paypal_fee').addClass('disabled');
                $('#amount').removeClass('disabled');
                $('#dateofdeposit').removeClass('disabled');
                $('#paypal_fee').val(0);
              }
          }

                                                    </script>
                                                    <script>
                                                    $(function () {
                                                    //Initialize Select2 Elements
                                                    $(".select2").select2();
                                                    //Datemask dd/mm/yyyy
                                                    $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
                                                    //Datemask2 mm/dd/yyyy
                                                    $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
                                                    //Money Euro
                                                    $("[data-mask]").inputmask();
                                                    //Date range picker
                                                    $('#reservation').daterangepicker();
                                                    //Date range picker with time picker
                                                    $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
                                                    //Date range as a button
                                                    $('#daterange-btn').daterangepicker(
                                                    {
                                                    ranges: {
                                                    'Today': [moment(), moment()],
                                                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                                                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                                    },
                                                    startDate: moment().subtract(29, 'days'),
                                                    endDate: moment()
                                                    },
                                                    function (start, end) {
                                                    $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
                                                    }
                                                    );
                                                    //iCheck for checkbox and radio inputs
                                                    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
                                                    checkboxClass: 'icheckbox_minimal-blue',
                                                    radioClass: 'iradio_minimal-blue'
                                                    });
                                                    //Red color scheme for iCheck
                                                    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
                                                    checkboxClass: 'icheckbox_minimal-red',
                                                    radioClass: 'iradio_minimal-red'
                                                    });
                                                    //Flat red color scheme for iCheck
                                                    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
                                                    checkboxClass: 'icheckbox_flat-green',
                                                    radioClass: 'iradio_flat-green'
                                                    });
                                                    //Colorpicker
                                                    $(".my-colorpicker1").colorpicker();
                                                    //color picker with addon
                                                    $(".my-colorpicker2").colorpicker();
                                                    //Timepicker
                                                    $(".timepicker").timepicker({
                                                    showInputs: false
                                                    });
                                                    });
                                                    </script>
                                                  </body>
                                                </html>