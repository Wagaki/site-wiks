<?php
 $subject = $foldername = $_POST["foldername"]; 
 mkdir($foldername, 0700);
?>