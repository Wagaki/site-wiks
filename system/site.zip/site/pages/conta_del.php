<?php
include("../dist/includes/dbcon.php");
$id = $_GET['id_code'];
$result=mysqli_query($con,"DELETE FROM contact WHERE id_code ='$id'")
	or die(mysqli_error());
	
echo "<script>document.location='contact.php?'</script>";  
?>