<?php

include('../dist/includes/dbcon.php');
$dir_name = $_POST['folder_name'];
$result = mkdir("Documents/".$dir_name);
if($result){
	mysqli_query($con,"INSERT INTO folders(name)VALUES('$dir_name')")or die(mysqli_error($con));

	$status = "Directory created as $dir_name";
} else {
	$status = "Error";
}

header("location:document.php?status=$status");
?>