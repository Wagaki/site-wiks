<?php 
session_start();
include('../dist/includes/dbcon.php');
	$branch=$_SESSION['branch'];
	$first = $_POST['first'];
	$last = $_POST['last'];
	$email = $_POST['email'];
	
	$query2=mysqli_query($con,"select * from email where first_name='$first' and last_name='$last'")or die(mysqli_error($con));
		$count=mysqli_num_rows($query2);
		$row=mysqli_fetch_array($query2);
			$id=$row['email_id'];

		if ($count>0)
		{
			mysqli_query($con,"update email where email_id='$id'")or die(mysqli_error());
	
			echo "<script type='text/javascript'>alert('Application resubmitted for approval!');</script>";
			echo "<script>document.location='creditor.php'</script>";  
		}
		else
		{	
			
			mysqli_query($con,"INSERT INTO email(first_name,last_name, email) 
				VALUES('$first','$last','$email')")or die(mysqli_error($con));

			$id=mysqli_insert_id($con);
			//$_SESSION['cid']=$id;
			echo "<script type='text/javascript'>alert('Successfully added new email! .');</script>";
			echo "<script>document.location='creditor.php'</script>";  
		}
?>