<?php 
session_start();
require('../dist/includes/dbcon.php');
//require('model/customer_functions.php');
	$salutation =$_POST['salutation'];
	$salutation_2 =$_POST['salutation_2'];
	$address = $_POST['address'];
	$address_2 = $_POST['address_2'];
	$city =$_POST['city'];
	$state =$_POST['state'];
	$zipcode = $_POST['zipcode'];
	$country = $_POST['country'];
	$firstname =$_POST['firstname'];
	$lastname =$_POST['lastname'];
	$email = $_POST['email'];
	$prayerpartner = $_POST['prayerpartner'];
	$firstname_2 =$_POST['firstname_2'];
	$lastname_2 =$_POST['lastname_2'];
	$email_2 = $_POST['email_2'];
	$firstname_3 =$_POST['firstname_3'];
	$lastname_3 =$_POST['lastname_3'];
	$email_3 = $_POST['email_3'];
	$notes = $_POST['notes'];
	$frequency = $_POST['frequency'];
	$donor_class = $_POST['donor_class'];
    $paypal_email = $_POST['paypal_email'];
    $paypal_email_2 = $_POST['paypal_email_2'];
    $phone_number = $_POST['phone_number'];


	//var_dump($_POST);die();
	
	//Add a New Customer
	//Create the data array
	/* $data = array(
		
		'salutation' => $salutation,
		'salutation_2' => $salutation_2,
		'address' =>$address,
		'address_2' =>$address_2,
		'city' =>$city,
		'state' =>$state,
		'zipcode' =>$zipcode,
		'country'=>$country,
		'firstname' =>$firstname,
		'lastname' =>$lastname,
		'email'=>$email,
		'prayerpartner' =>$prayerpartner,
		'firstname_2' =>$firstname_2,
		'lastname_2' =>$lastname_2,
		'email_2' =>$email_2,
		'firstname_3' =>$firstname_3,
		'lastname_3' =>$lastname_3,
		'email_3' =>$email_3,
		'notes' =>$notes,
		'frequency' =>$frequency,
		'donor_class' =>$donor_class,
        'paypal_email' =>$paypal_email,
         'paypal_email_2' =>$paypal_email_2,
         'phone_number' =>$phone_number,

         
		
	);
	
	$result = addCustomer($con,$data);
	if($result){
		$status = "Contact Added Successfully.";
	}else{
		$status = "Error while adding contact.";
	}
	
	die(); */
	$sql = "INSERT INTO contact(salutation,salutation_2,address,address_2,city,state,zipcode,country,firstname,lastname,email,prayerpartner,firstname_2,lastname_2,email_2,firstname_3,lastname_3,email_3,notes,frequency,donor_class,paypal_email,paypal_email_2,phone_number) 
				VALUES('$salutation','$salutation_2','$address','$address_2','$city','$state','$zipcode','$country','$firstname','$lastname','$email','$prayerpartner','$firstname_2','$lastname_2','$email_2','$firstname_3','$lastname_3','$email_3','$notes','$frequency','$donor_class','$paypal_email','$paypal_email_2','$phone_number')";


			
			mysqli_query($con,$sql)or die(mysqli_error($con));

			$id=mysqli_insert_id($con);
			$_SESSION['cid']=$id;
			echo "<script type='text/javascript'>alert('Successfully added new contact!');</script>";
			echo "<script>document.location='customer.php?cid=$id'</script>";  
		
?>