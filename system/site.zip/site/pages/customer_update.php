<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;

require('../dist/includes/dbcon.php');
	$id = $_POST['id'];
	$salutation =$_POST['salutation'];
	$salutation_2 =$_POST['salutation_2'];
	$address = $_POST['address'];
	$address_2 = $_POST['address_2'];
	$city =$_POST['city'];
	$state =$_POST['state'];
	$zipcode = $_POST['zipcode'];
	$country = $_POST['country'];
	$firstname =$_POST['firstname'];
	$lastname =$_POST['lastname'];
	$email = $_POST['email'];
	$phone_number = $_POST['phone_number'];
	$prayerpartner = $_POST['prayerpartner'];
	$firstname_2 =$_POST['firstname_2'];
	$lastname_2 =$_POST['lastname_2'];
	$email_2 = $_POST['email_2'];
	$firstname_3 =$_POST['firstname_3'];
	$lastname_3 =$_POST['lastname_3'];
	$email_3 = $_POST['email_3'];
	$notes = $_POST['notes'];
	$frequency = $_POST['frequency'];
	$donor_class = $_POST['donor_class'];
     $paypal_email = $_POST['paypal_email']; 
      $paypal_email_2 = $_POST['paypal_email_2'];    
        
        $sql = "update contact set salutation=\"$salutation\",salutation_2=\"$salutation_2\",address=\"$address\",address_2=\"$address_2\",city=\"$city\",state=\"$state\",zipcode=\"$zipcode\",country=\"$country\",firstname=\"$firstname\",lastname=\"$lastname\",email=\"$email\",phone_number=\"$phone_number\",prayerpartner=\"$prayerpartner\",firstname_2=\"$firstname_2\",lastname_2=\"$lastname_2\",email_2=\"$email_2\",firstname_3=\"$firstname_3\",lastname_3=\"$lastname_3\",email_3=\"$email_3\",notes=\"$notes\",frequency=\"$frequency\",donor_class=\"$donor_class\",paypal_email=\"$paypal_email\",paypal_email_2=\"$paypal_email_2\" where id_code=\"$id\"";
	
	mysqli_query($con,$sql)or die(mysqli_error($con));
	
	echo "<script type='text/javascript'>alert('Successfully updated contact details!');</script>";
	echo "<script>document.location='customer.php'</script>";  

	
?>
