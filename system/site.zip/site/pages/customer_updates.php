<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Contact | <?php include('../dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="../plugins/select2/select2.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
    <style>
      
    </style>
 </head>
  <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
  <body class="hold-transition skin-<?php echo $_SESSION['skin'];?> layout-top-nav">
    <div class="wrapper">
      <?php include('../dist/includes/header.php');
      include('../dist/includes/dbcon.php');
      ?>
      <!-- Full Width Column -->
      <div class="content-wrapper">
        <div class="container">
          <!-- Content Header (Page header) -->
          <section class="content-header">
            <h1>
              <a class="btn btn-lg btn-warning" href="home.php">Back</a>
              
            </h1>
            <ol class="breadcrumb">
              <li><a href="home.php"><i class="fa fa-dashboard"></i> Home</a></li>
              <li class="active">Contact</li>
            </ol>
          </section>

          <!-- Main content -->
          <section class="content">
            <div class="row">
	          
			
            <div class="col-xs-12">
              <div class="box box-primary">
    
                <div class="box-header">
                  <h3 class="box-title">Contact List</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
            			<th>Id_Code</th>
            			<th>Salutation</th>
                        <th>Salutation_2</th>
                        <th>Address</th>
                        <th>Address_2</th>
            			<th>City</th>
            			<th>State</th>
                        <th>Zipcode</th>
            			<th>Country</th>
                        <th>Action</th>
						
                      </tr>
                    </thead>
                    <tbody>
<?php
		$cid=$_POST['cid'];
		$query=mysqli_query($con,"select * from contact where id_code='$cid'")or die(mysqli_error($con));
		$i=1;
		while($row=mysqli_fetch_array($query)){
		$cid=$row['id_code'];
?>
                      <tr>
					    <td><?php echo $row['id_code'];?></td>
						<td><?php echo $row['salutation'];?></td>
                        <td><?php echo $row['salutation_2'];?></td>
                        <td><?php echo $row['address'];?></td>
                        <td><?php echo $row['address_2'];?></td>
						<td><?php echo $row['city'];?></td>
						<td><?php echo $row['state'];?></td>
           				<td><?php echo $row['zipcode'];?></td>
						<td><?php echo $row['country'];?></td>
                        <td>
				<a href="<?php echo "account_summary.php?cid=$cid";?>"><i class="glyphicon glyphicon-share-alt text-green"></i></a>
				<a href="#updateordinance<?php echo $row['id_code'];?>" data-target="#updateordinance<?php echo $row['id_code'];?>" data-toggle="modal" style="color:#fff;" class="small-box-footer"><i class="glyphicon glyphicon-edit text-blue"></i></a>
				
						</td>
                      </tr>
				<div id="updateordinance<?php echo $row['id_code'];?>" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog">
	  <div class="modal-content" style="height:auto">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Update Contact Details</h4>
              </div>
              <div class="modal-body">
			  <form class="form-horizontal" method="post" action="customer_update.php" enctype='multipart/form-data'>
                
				<div class="form-group">
					<label class="control-label col-lg-3" for="name">Salutation</label>
					<div class="col-lg-9">
						<input type="hidden" class="form-control" id="id" name="id" value="<?php echo $row['id_code'];?>">  
						<input type="text" class="form-control" name="salutation" value="<?php echo $row['salutation'];?>">  
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-lg-3" for="name">Salutation_2</label>
					<div class="col-lg-9">
						<input type="text" class="form-control" id="name" name="salutation_2" value="<?php echo $row['salutation_2'];?>">  
					</div>
				</div>				
				<div class="form-group">
					<label class="control-label col-lg-3" for="file">Address</label>
					<div class="col-lg-9">
					<input type="text" class="form-control" id="name" name="address" value="<?php echo $row['address'];?>"> 
				</div> 
				</div>
				<div class="form-group">
					<label class="control-label col-lg-3" for="price">Address_2</label>
					<div class="col-lg-9">
					  <input type="text" class="form-control" id="price" name="address_2" value="<?php echo $row['address_2'];?>">  
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-lg-3" for="name">City</label>
					<div class="col-lg-9">
						<input type="text" class="form-control" id="name" name="city" value="<?php echo $row['city'];?>">  
					</div>
				</div>				
				<div class="form-group">
					<label class="control-label col-lg-3" for="file">State</label>
					<div class="col-lg-9">
					<select class="form-control pull-right" id="date" name="state">
                                         <option value=""></option>
						   <?php
            
              $query2=mysqli_query($con,"select * from states ORDER BY abreviation ASC")or die(mysqli_error());
                while($row2=mysqli_fetch_array($query2)){
                ?>
                  <option value="<?php echo $row2['state_name'];?>" <?php if($row2['state_name'] == $row['state']){echo "selected";}  ?> ><?php echo $row2['state_name'];?></option>
                <?php }?>
                        </select>
				</div> 
				</div>
				<div class="form-group">
					<label class="control-label col-lg-3" for="price">Zipcode</label>
					<div class="col-lg-9">
					<input type="text" class="form-control" id="price" name="zipcode" value="<?php echo $row['zipcode'];?>">  
					</div>
				</div>
           
			  <div class="form-group">
					<label class="control-label col-lg-3" for="name">Country</label>
					<div class="col-lg-9">
						<input type="text" class="form-control" id="name" name="country" value="<?php echo $row['country'];?>">  
					</div>
				</div>				
				<div class="form-group">
					<label class="control-label col-lg-3" for="name">First name</label>
					<div class="col-lg-9">
					<input type="text" class="form-control"  name="firstname" value="<?php echo $row['firstname'];?>"> 
				</div>
				</div>
				<div class="form-group">
					<label class="control-label col-lg-3" for="name">Last name</label>
					<div class="col-lg-9">
					  <input type="text" class="form-control" name="lastname" value="<?php echo $row['lastname'];?>">  
					</div>
				</div>
				 <div class="form-group">
					<label class="control-label col-lg-3" for="name">Email</label>
					<div class="col-lg-9">
					 <input type="text" class="form-control" name="email" value="<?php echo $row['email'];?>">  
					</div>
				</div>
			
				<div class="form-group">
					<label class="control-label col-lg-3" for="name">Phone Number</label>
					<div class="col-lg-9">
					 <input type="text" class="form-control" name="phone_number" value="<?php echo $row['phone_number'];?>">  
					</div>
				</div>				
				<div class="form-group">
					<label class="control-label col-lg-3" for="name">Prayerpartner</label>
					<div class="col-lg-9">
                     <input type="radio" name="prayerpartner" value="true" <?php if($row['prayerpartner'] == 'true' || $row['prayerpartner'] == 'TRUE') {echo "checked";}?>> True<br>
					<input type="radio" name="prayerpartner" value="false" <?php if($row['prayerpartner'] == 'false' || $row['prayerpartner'] == 'FALSE') {echo "checked";}?>> False<br
				</div>
				</div>
              
			 <div class="form-group">
					<label class="control-label col-lg-3" for="name">Firstname_2</label>
					<div class="col-lg-9">
					<input type="text" class="form-control" name="firstname_2" value="<?php echo $row['firstname_2'];?>"> 
				</div>
				</div>
				<div class="form-group">
					<label class="control-label col-lg-3" for="name">Lastname_2</label>
					<div class="col-lg-9">
					  <input type="text" class="form-control"  name="lastname_2" value="<?php echo $row['lastname_2'];?>">  
					</div>
				</div>
				 <div class="form-group">
					<label class="control-label col-lg-3" for="name">Email_2</label>
					<div class="col-lg-9">
					 <input type="text" class="form-control" name="email_2" value="<?php echo $row['email_2'];?>">  
					</div>
				</div>				
				
				<div class="form-group">
					<label class="control-label col-lg-3" for="name">Firstname_3</label>
					<div class="col-lg-9">
					<input type="text" class="form-control" name="firstname_3" value="<?php echo $row['firstname_3'];?>"> 
				</div>
				</div>
				<div class="form-group">
					<label class="control-label col-lg-3" for="name">Lastname_3</label>
					<div class="col-lg-9">
					  <input type="text" class="form-control" name="lastname_3" value="<?php echo $row['lastname_3'];?>">  
					</div>
				</div>
				 <div class="form-group">
					<label class="control-label col-lg-3" for="name">Email_3</label>
					<div class="col-lg-9">
					 <input type="text" class="form-control" name="email_3" value="<?php echo $row['email_3'];?>">  
					</div>
				</div>				
				
				
				 <div class="form-group">
					<label class="control-label col-lg-3" for="name">Notes</label>
					<div class="col-lg-9">
						<textarea class="form-control"  name="notes" value="<?php echo      $row['notes'];?>"></textarea>
					</div>
					</div>
                    <div class="form-group">
					<label class="control-label col-lg-3" for="name">Frequency</label>
					<div class="col-lg-9">
                   	<select class="form-control pull-right" id="date" name="frequency">
                      <option value=""></option>
						   <?php
            
              $query2=mysqli_query($con,"select * from frequency")or die(mysqli_error());
                while($row2=mysqli_fetch_array($query2)){
                ?>
                  <option value="<?php echo $row2['frequency_name'];?>" <?php if($row2['frequency_name'] == $row['frequency']){echo "selected";}  ?> ><?php echo $row2['frequency_name'];?></option>
                <?php }?>
                        </select>
				</div> 
				</div>
				
				 <div class="form-group">
					<label class="control-label col-lg-3" for="name">Donor Class</label>
					<div class="col-lg-9">
                   	<select class="form-control pull-right" id="date" name="donor_class">
                       <option value="" ></option>
                            <?php
            
              $query2=mysqli_query($con,"select * from donor_class")or die(mysqli_error());
                while($row2=mysqli_fetch_array($query2)){
                ?>
                  <option value="<?php echo $row2['donor_name'];?>"><?php echo $row2['donor_name'];?></option>
                <?php }?>
                </select>
				</div> 
				</div>
				
				
                    <div class="form-group">
					<label class="control-label col-lg-3" for="name">Paypal_Email</label>
					<div class="col-lg-9">
					 <input type="text" class="form-control" name="paypal_email" value="<?php echo $row['paypal_email'];?>">  
					</div>
				</div>	
				<div class="form-group">
					<label class="control-label col-lg-3" for="name">Paypal Email_2</label>
					<div class="col-lg-9">
					 <input type="text" class="form-control" name="paypal_email_2" value="<?php echo $row['paypal_email_2'];?>">  
					</div>
				</div>	
			 </div><br><br><br><hr>
			  
              <div class="modal-footer">
		<button type="submit" class="btn btn-primary">Save changes</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
			  </form>
            </div>
			
        </div><!--end of modal-dialog-->
 </div>
 <!--end of modal-->   	  
                 
<?php $i++;}?>					  
                    </tbody>
                   
                  </table>
                </div><!-- /.box-body -->
 
            </div><!-- /.col -->
			
			
          </div><!-- /.row -->
	 
            
          </section><!-- /.content -->
        </div><!-- /.container -->
      </div><!-- /.content-wrapper -->
      <?php include('../dist/includes/footer.php');?>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../plugins/select2/select2.full.min.js"></script>
    <!-- SlimScroll -->
    <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="../plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../dist/js/demo.js"></script>
    <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
    
    <script>
      $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>
     <script>
      $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

        //Datemask dd/mm/yyyy
        $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
        //Datemask2 mm/dd/yyyy
        $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
        //Money Euro
        $("[data-mask]").inputmask();

        //Date range picker
        $('#reservation').daterangepicker();
        //Date range picker with time picker
        $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
        //Date range as a button
        $('#daterange-btn').daterangepicker(
            {
              ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
              },
              startDate: moment().subtract(29, 'days'),
              endDate: moment()
            },
        function (start, end) {
          $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        }
        );

        //iCheck for checkbox and radio inputs
        $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
          checkboxClass: 'icheckbox_minimal-blue',
          radioClass: 'iradio_minimal-blue'
        });
        //Red color scheme for iCheck
        $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
          checkboxClass: 'icheckbox_minimal-red',
          radioClass: 'iradio_minimal-red'
        });
        //Flat red color scheme for iCheck
        $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
          checkboxClass: 'icheckbox_flat-green',
          radioClass: 'iradio_flat-green'
        });

        //Colorpicker
        $(".my-colorpicker1").colorpicker();
        //color picker with addon
        $(".my-colorpicker2").colorpicker();

        //Timepicker
        $(".timepicker").timepicker({
          showInputs: false
        });
      });
    </script>
  </body>
</html>
