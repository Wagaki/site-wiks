<?php
session_start();
require 'model/crud.php';
if($_SESSION['position'] != 'banker' && $_SESSION['position'] != 'administration' ):
	header('Location:../index.php');
	echo $_SESSION['position'];
	die('You are not allowed to acces this page..');
endif;

$conn = dbconnect();

if ($conn) {
	$id_code = $_GET['id_code'];
	$sql = "DELETE FROM contact WHERE id_code = \"$id_code\"";
	$result = deleteData($conn, $sql);

	if ($result) {

		header('Location:contact.php');die('Deleted Successfully.');
	} 
else {

		header('Location:contact.php');die('Error while deleting.');		
	}


} else {
	echo('Error while connecting... Please wait while we redirect you');
	//header('Location:../index.php');
	die();
}





?>