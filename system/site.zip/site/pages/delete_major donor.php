<?php
session_start();
require 'model/crud.php';
if($_SESSION['position'] != 'banker' && $_SESSION['position'] != 'administration' ):
	header('Location:../index.php');
	echo $_SESSION['position'];
	die('You are not allowed to acces this page..');
endif;

$conn = dbconnect();

if ($conn) {
	$id_no = $_GET['id_no'];
	$sql = "DELETE FROM donation WHERE id_no = $id_no";
	$result = deleteData($conn, $sql);

	if ($result) {

		header('Location:major-donors.php');die('Deleted Successfully.');
	} else {

		header('Location:major-donors.php');die('Error while deleting.');		
	}

} else {
	echo('Error while connecting... Please wait while we redirect you');
	//header('Location:../index.php');
	die();
}





?>