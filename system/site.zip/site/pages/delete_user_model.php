<?php
	include('../dist/includes/dbcon.php');
	$id=$_GET['id'];
	
$query1=mysqli_query($con,"DELETE FROM user WHERE user_id= $id")or die(mysqli_error($con));
	
	
	
	
	header("location: user.php");
?>