<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Donation | <?php include('../dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="../plugins/select2/select2.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
    <style>
      

      #update {
        position: fixed;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        background: rgba(0,0,0,0.7);
        z-index: 9;
        display: none;
        overflow: auto;
      }
      .update-panel {
        background-color: white;
        margin: 8% 8% 8% 8%;
        border-radius: 10px;
        padding-top: 5px;
        padding-bottom: 5px;
        padding-left: 5px;
        padding-right: 5px;
      }
      
      .disabled {
      	pointer-events: none;
      	background-color: #eee;
      }


      @-webkit-keyframes rotating {
        from {
          -webkit-transform: rotate(0deg);

        }

        to {
          -webkit-transform: rotate(360deg);    
        }
      }

      @keyframes rotating {
        from {
          transform: rotate(0deg);

        }

        to {
          transform: rotate(360deg);    
        }
      }

      .circular {
        animation: rotating 1.5s linear infinite;
        position: relative;
      }
    </style>
    <!-- jQuery 2.1.4 -->
    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
 </head>
  <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
  <body class="hold-transition skin-<?php echo $_SESSION['skin'];?> layout-top-nav">
    <div class="wrapper">
      <?php include('../dist/includes/header.php');
      include('../dist/includes/dbcon.php');
      ?>
      <!-- Full Width Column -->
      <div class="content-wrapper">
        <div class="container">
          <!-- Content Header (Page header) -->
          <section class="content-header">
            <h1>
              <a class="btn btn-lg btn-warning" href="download.php">Back</a>
               <a class="btn btn-lg btn-primary" href="exportdon.php">Export</a>
            </h1>
            <ol class="breadcrumb">
              <li><a href="home.php"><i class="fa fa-dashboard"></i> Home</a></li>
              <li class="active">Donor Annual Totals</li>
            </ol>
          </section>

          <!-- Main content -->
          <section class="content">
            <div class="row">
	          
			
            <div class="col-xs-12">
              <div class="box box-primary">
    
                <div class="box-header">
                  <h3 class="box-title">Donor Annual Totals</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
			<th>Salutation</th>
			<th>Amount</th>
            <th>Year</th>
             <th>City</th>
			<th>State</th>
            <th>Last Name</th>
            	<?php if ($_SESSION['position'] == 'banker' || $_SESSION['position'] == 'administration'): ?>
              		<th>Action</th>
            	<?php endif ?>
                       
                      </tr>
                    </thead>
                    <tbody>
<?php
	
		$query=mysqli_query($con,"select c.salutation,d.amount,d.category,d.donation_type,d.check_no,d.dateofcheck,d.dateofdeposit,d.dateforacknowledge,d.notes,c.lastname FROM donation d,contact c where d.id_code=c.id_code order by d.dateofdeposit asc")or die(mysqli_error($con));
		$i=1;
		while($row=mysqli_fetch_array($query)){
		$cid=$row['id_code'];
    $id_no = $row['id_no'];
    $id = $id_no;
		
?>           			
		<tr>
        <td id="idcode-<?=$cid?>"><?php echo $row['id_code'];?></td>
	 <td id="salutation-<?=$cid?>"><?php echo $row['salutation'];?></td>
        <td id="amount-<?=$cid?>"><?php echo $row['amount'];?></td>
        <td id="cat-<?=$cid?>"><?php echo $row['category'];?></td>
        <td id="dontype-<?=$cid?>"><?php echo $row['donation_type'];?></td>
	 <td id="checkno-<?=$cid?>"><?php echo $row['check_no'];?></td>
        <td id="dateofcheck-<?=$cid?>"><?php echo $row['dateofcheck'];?></td>
        <td id="dateofdepo-<?=$cid?>"><?php echo $row['dateofdeposit'];?></td>
	 <td id="lastname-<?=$cid?>"><?php echo $row['lastname'];?></td>
					
        <?php if ($_SESSION['position'] == 'banker' || $_SESSION['position'] == 'administration' ): ?>
		      <td>
<a title="Update" href="javascript:updateDonation('<?php echo $id;?>')"><i class="glyphicon glyphicon-edit"></i></a>
 <a title="Delete" href="javascript:deleteDonation('<?php echo $id;?>')"><i class="glyphicon glyphicon-trash text-danger"></i></a>
		      </td>
        <?php endif ?>
    </tr>

        <?php if ($_SESSION['position'] == 'banker' || $_SESSION['position'] == 'administration' ): ?>
				  <!-- <?php //require("update_donation_modal.php"); ?> -->
        <?php endif ?>
			
        </div><!--end of modal-dialog-->
 </div>
 <!--end of modal--> 


                 
<?php $i++;}?>					  
                    </tbody>
                   
                  </table>
                </div><!-- /.box-body -->
 
            </div><!-- /.col -->
			
			
          </div><!-- /.row -->
	 
            
          </section><!-- /.content -->
        </div><!-- /.container -->
      </div><!-- /.content-wrapper -->
      <?php include('../dist/includes/footer.php');?>
    </div><!-- ./wrapper -->

<!-- updating popup starts here -->
  <div id="update" class="row">
    <div class="update-panel container"> 
      <a class="pull-right text-danger" href="javascript:close_popup('update')"><i class="glyphicon glyphicon-remove"></i></a> 
      <div id="working-form">
        <div class=" text-center text-primary" style="font-size: 4em; margin-top: 8%; margin-bottom: 8%;">
          <i  class="glyphicon glyphicon-refresh circular"></i>
          <br>
          <h3>Fetching Donation Information</h3>
          <h4>Hold on...</h4>
        </div>
      </div>

      <div id="update-form" class="hidden">
          <h3 class="text-center">Update Donation</h3>
          <div id="status"></div>
          <form method = "POST" action = "update_donation.php" id = 'don-update-form'> 
            <input id="txt-idno" type="hidden" name="user_id" >
            <div class="row container">
              <div class="col-lg-6">
                
                <label>ID Code</label>
                <input id="txt-idcode" type="text" name = "id-code" class="form-control" readonly disabled>
              </div>

              <div class="col-lg-6 col-md-6">
                
                <label>Salutation</label>
                <input id="txt-salutation" type="text" name = "name" class="form-control" readonly disabled>
              </div>
            </div>

            <div class="row container">
              <div class="col-lg-6">
                
                <label>Amount</label>
                <input id="txt-amount" type="number" name = "amount" class="form-control">
              </div>

              <div class="col-lg-6 col-md-6">               
                
                <label>Check Number</label>
                <input id="txt-checkno" type="text" name = "check-no" class="form-control">
              </div>
            </div>   

            <div class="row container">
              <div class="col-lg-6">
                
                <label>Date of Check</label>
                <input id="txt-dateofcheck" type="text" name = "dateofcheck" class="form-control">
              </div>

              <div class="col-lg-6 col-md-6">               
                
                <label>Date of deposit</label>
                <input id="txt-dateofdeposit" type="text" name = "dateofdeposit" class="form-control">
              </div>
            </div>

            
              <div class="col-lg-6">                
            
                <label for="date">Category</label>
               <select id='category_sel' class="form-control" style="width: 100%;" name="category">
               <option value="null">Select Category</option>
                    <?php
	         $query2=mysqli_query($con,"select * from category")or die(mysqli_error());
             while($row2=mysqli_fetch_array($query2)){
	                                            ?>
	      <option value="<?php echo $row2['cat_name'];?>"><?php echo $row2['cat_name'];?></option>
	                                            <?php }?>
	                                          </select>	

                                                </div>
                                           

              <div class="col-lg-6 col-md-6">               
                
                
                <label for="date">Donation Type</label>
                <select id="donation_type" class="form-control" style="width: 100%;" name="donation_type" onchange='checkDonType()'>
                    <option value="null">Select Donation Type</option>
                    <?php
                      $query2=mysqli_query($con,"select * from donationtype")or die(mysqli_error());
                      while($row2=mysqli_fetch_array($query2)){
                      ?>
                      <option value="<?php echo $row2['don_name'];?>"><?php echo $row2['don_name'];?></option>
                    <?php }?>
                </select>
              </div>

            	
	        
	        <div class="col-lg-6">
	                              
	                <label>Last Name</label>
	                <input id="txt-lastname" name = "lastname" class="form-control disabled" >
	                <br/>
	        </div>
              
                   
            </div>  
         

            <div class="row container">
              

            </div>           
            
            <div class="container" style="padding-right: 20px;">              
              <p class="text-center"><button  name = "update" class="btn btn-primary" id='btn-update'>Save changes</button></p>
            </div> 
          </form>
      </div>    
      
      <div id="preview"></div>
    </div>
            
  </div>
<!-- updating popup ends here -->

    <!-- Bootstrap 3.3.5 -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../plugins/select2/select2.full.min.js"></script>
    <!-- SlimScroll -->
    <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="../plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../dist/js/demo.js"></script>
    <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
    
    <script>
	
      function updateDonation(dId) {
        $('#working-form').removeClass('hidden');
        $('#update-form').addClass('hidden');
        show_popup('update');

        $.ajax({
        url:"fetch_donation_info.php",
          data: {'id_no':dId},
          type: 'POST',
          success: function(response) {
              $('#preview').html(response);             
          }
      });
      }
      function deleteDonation(dId) {
        if (confirm('Are you sure you want to delete the Donation')) {

          window.location.href = 'delete_donation.php?id_no='+dId;
        }
      }

      function show_popup(id) {
        $('#'+id).show();
      }
    
      function close_popup(id) {
        
        $('#'+id).hide();
      }
      
      function checkDonType() {
      	var dontype = document.getElementById('donation_type').value;
      	if (dontype == 'Check') {
	      	$('#txt-fee').addClass('disabled');
	      	$('#txt-checkno').removeClass('disabled');
	      	$('#txt-dateofcheck').removeClass('disabled');
	      	
      	} 
      }


        $("#don-update-form").submit(function() {
          var dontype = $('#donation_type').val();
          var category = $('#category').val();

          if (dontype == "null") {
            $('#status').html("<h4 class='text-danger text-center'>Select Donation Type</h4>");
            return false;
          }
          
          if (dontype == 'Check') {
	      	if ($('#txt-checkno').val() == '') {
	            $('#status').html("<h4 class='text-danger text-center'>Check Number is required</h4>");
	            return false;
	      	}
	      	
	      	if ($('#txt-dateofcheck').val() == '') {
	            $('#status').html("<h4 class='text-danger text-center'>Date of Check is required</h4>");
	            return false;
	      	}
	      	
      	  } 
          if (category == "null") {
            $('#status').html("<h4 class='text-danger text-center'>Select Category</h4>");
            return false;
          }
          $("#btn-update").html("Updating! Hold on... <i class='glyphicon glyphicon-refresh circular text-success'></i>");
          $("#btn-update").addClass("disabled");
      
          $.post($(this).attr("action"), $(this).serialize(),function(data) {
                $("#preview").html(data);
          });
      
                  
          return false;
        });

      $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>

  </body>
</html>
