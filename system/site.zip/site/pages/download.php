<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Download List | <?php include('../dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="../plugins/select2/select2.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
    <style>
      
    </style>
 </head>
  <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
  <body class="hold-transition skin-<?php echo $_SESSION['skin'];?> layout-top-nav">
    <div class="wrapper">
      <?php include('../dist/includes/header.php');
      include('../dist/includes/dbcon.php');
      ?>
      <!-- Full Width Column -->
      <div class="content-wrapper">
        <div class="container">
          <!-- Content Header (Page header) -->
          <section class="content-header hidden-print">
            <h1>
              <a class="btn btn-lg btn-warning" href="home.php">Back</a>
            </h1>
            <ol class="breadcrumb">
              <li><a href="home.php"><i class="fa fa-dashboard"></i> Home</a></li>
              <li class="active">DOWNLOADS</li>
            </ol>
          </section>

          <!-- Main content -->
          <section class="content">
	          <br><br>
            <div class="col-lg-4 col-md-4 col-xs-12 col-sm-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h3>Contacts List</h3>
                  <p>View</p>
                </div>
                <div class="icon" style="margin-top:10px">
                  <i class="glyphicon glyphicon-user"></i>
                </div>
                <a href="contact.php" class="small-box-footer">
                  Go <i class="fa fa-arrow-circle-right"></i>
                </a>
              </div>
            </div><!-- ./col -->

            <div class="col-lg-4 col-md-4 col-xs-12 col-sm-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h3>Postals</h3>
                  <p>View</p>
                </div>
                <div class="icon" style="margin-top:10px">
                  <i class="glyphicon glyphicon-envelope"></i>
                </div>
                <a href="application.php" class="small-box-footer">
                  Go <i class="fa fa-arrow-circle-right"></i>
                </a>
              </div>
            </div><!-- ./col --> 

             <div class="col-lg-4 col-md-4 col-xs-12 col-sm-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h3>Emails</h3>
                  <p>View</p>
                </div>
                <div class="icon" style="margin-top:10px">
                  <i class="glyphicon glyphicon-envelope"></i>
                </div>
                <a href="creditor.php" class="small-box-footer">
                  Go <i class="fa fa-arrow-circle-right"></i>
                </a>
              </div>
            </div><!-- ./col -->

            <div class="col-lg-4 col-md-4 col-xs-12 col-sm-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h3>Donations</h3>
                  <p>View</p>
                </div>
                <div class="icon" style="margin-top:10px">
                  <i class="glyphicon glyphicon-usd"></i>
                </div>
                <a href="product.php" class="small-box-footer">
                  Go <i class="fa fa-arrow-circle-right"></i>
                </a>
              </div>
            </div><!-- ./col --> 

         <div class="col-lg-4 col-md-4 col-xs-12 col-sm-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h3>Deposits</h3>
                  <p>View</p>
                </div>
                <div class="icon" style="margin-top:10px">
                  <i class="glyphicon glyphicon-check"></i>
                </div>
                <a href="deposits.php" class="small-box-footer">
                  Go <i class="fa fa-arrow-circle-right"></i>
                </a>
              </div>
            </div><!-- ./col --> 

            <div class="col-lg-4 col-md-4 col-xs-12 col-sm-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h3>Prayer Partner</h3>
                  <p>View</p>
                </div>
                <div class="icon" style="margin-top:10px">
                  <i class="glyphicon glyphicon-user"></i>
                </div>
                <a href="prayer_partner.php" class="small-box-footer">
                  Go <i class="fa fa-arrow-circle-right"></i>
                </a>
              </div>
            </div><!-- ./col --> 


          </section><!-- /.content -->
        </div><!-- /.container -->
      </div><!-- /.content-wrapper -->
      <?php include('../dist/includes/footer.php');?>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../plugins/select2/select2.full.min.js"></script>
    <!-- SlimScroll -->
    <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="../plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../dist/js/demo.js"></script>
    
  </body>
</html>
