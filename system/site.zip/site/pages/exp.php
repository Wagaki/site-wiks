<?php
include 'export_config.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Export data into Excel | Webdiea4u</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" href="js/bootstrap.js"></script>
	<script type="text/javascript" href="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
	<div class="row">
		<?php
			$data = new Connection();
			$userData = $data->getRows();
		?>
	</div>
</div>
</body>
</html>