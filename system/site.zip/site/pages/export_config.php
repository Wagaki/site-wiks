<?php
/**
* Database Configuration
*/
class Connection{
    public $dbHost     = "localhost";
    public $dbUsername = "nambalem_usa";
    public $dbPassword = "@usa2019";
    public $dbName     = "nambalem_inventory";
    public $userTbl    = "contact";
 
    public function __construct(){
        if(!isset($this->db)){
            // Connect to the database
            $conn = new mysqli($this->dbHost, $this->dbUsername, $this->dbPassword, $this->dbName);
            if($conn->connect_error){
                die("Failed to connect with MySQL: " . $conn->connect_error);
            }else{
                $this->db = $conn;
            }
        }
    }
 
    public function getRows()
    {
    	//$export = $this->getRowsExport();
    	$query = "SELECT * from `contact`";
    	$result = $this->db->query($query);
 
    	if($result->num_rows > 0){
    		$data = array();
    		?>
    		<a href="export.php" class="btn btn-success"> Export to Excel </a>
    		<table class="table table-hover">
    			<tr>
    				<th>ID</th>
    				<th>First Name</th>
    				<th>Last Name</th>
    				<th>Email</th>
    				<th>Message</th>
    			</tr>
    		<?php
	    	while ($row = $result->fetch_assoc()) {
	    		?>
	    		<tr>
	    			<td><?php echo $row['firstname'].""; ?></td>
                    <td><?php echo $row['lastname'].""; ?></td>
	    			<td><?php echo $row['email']; ?></td>
	    		</tr>
                <tr>
                    <td><?php echo $row['firstname_2'].""; ?></td>
                    <td><?php echo $row['lastname_2'].""; ?></td>
                    <td><?php echo $row['email_2']; ?></td>
                </tr>
                <tr>
                    <td><?php echo $row['firstname_3'].""; ?></td>
                    <td><?php echo $row['lastname_3'].""; ?></td>
                    <td><?php echo $row['email_3']; ?></td>
                </tr>
               
	    		<?php
	    	}
	    	?>
	    	</table>
	    	<?php
    	}
    }
}