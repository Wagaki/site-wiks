<?php  
  
include "export_config.php";
 
$data = new Connection();
$conn = new mysqli($data->dbHost, $data->dbUsername, $data->dbPassword);  
mysqli_select_db($conn, $data->dbName);  
 
$setSql = "SELECT d.id_no,d.id_code,c.salutation,d.amount,d.category,d.donation_type,d.check_no,d.dateofcheck,d.dateofdeposit,c.lastname,d.dateforacknowledge,c.state,c.zipcode,c.notes FROM donation d,contact c where d.id_code=c.id_code order by d.dateofdeposit";  
$setRec = mysqli_query($conn, $setSql); 
 
$columnHeader = '';  
$columnHeader = "Id_no" . "\t" . "Id_Code" . "\t" . "Salutation" . "\t" . "Amount" . "\t" . "Category" . "\t" . "Donation Type" . "\t" . "Check No" . "\t" .  "Date of Check" . "\t" . "Date of Deposit" . "\t" . "Lastname" . "\t" .  "Date Acknowledged" . "\t" . "State" . "\t" . "Zipcode" . "\t" . "notes" . "\t" . "";  
  
$setData = '';  
  
while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=Export_To_Excel.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  
  
echo ucwords($columnHeader) . "\n" . $setData . "\n";  
  
?>