<?php  
  
include "export_config.php";
 
$data = new Connection();
$conn = new mysqli($data->dbHost, $data->dbUsername, $data->dbPassword);  
mysqli_select_db($conn, $data->dbName);  
 
$setSql = "SELECT id_code, salutation, address,address_2, city, state, zipcode, country FROM contact where address is not null";  
$setRec = mysqli_query($conn, $setSql); 
 
$columnHeader = '';  
$columnHeader = "Id_Code" . "\t" . "Salutation" . "\t" . "Address" . "\t" . "address_2" . "\t" . "City" . "\t" . "State" . "\t" . "Zip Code" . "\t" . "country" . "\t" .  "";  
  
$setData = '';  
  
while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=Export_To_Excel.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  
  
echo ucwords($columnHeader) . "\n" . $setData . "\n";  
  
?>