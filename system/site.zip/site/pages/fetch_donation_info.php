<?php 
session_start();
require 'model/crud.php';
if($_SESSION['position'] != 'banker' && $_SESSION['position'] != 'administration' ):
  	header('Location:../index.php');
	die('You are not allowed to acces this page..');
endif;

$conn = dbconnect();

if ($conn) {
	$id_no = $_POST['id_no'];
	$sql = "SELECT d.id_no,d.id_code,c.salutation,d.amount,d.category,d.donation_type,d.check_no,d.dateofcheck, d.dateofdeposit,d.dateforacknowledge,d.notes,c.lastname FROM donation d,contact c WHERE d.id_no = \"$id_no\" AND d.id_code=c.id_code";
	$result = fetchData($conn, $sql);

	if ($result) {

		$result = $result[0];
                echo $result['donation_type'];
		extract($result);
		echo "
			<script>
				\$('#txt-idno').val(\"$id_no\");
				\$('#txt-idcode').val(\"$id_code\");
				\$('#txt-salutation').val(\"$salutation\");
				\$('#txt-lastname').val(\"$lastname\");
				\$('#txt-amount').val(\"$amount\");
				\$('#txt-checkno').val(\"$check_no\");
				\$('#txt-dateofcheck').val(\"$dateofcheck\");
				\$('#txt-dateofdeposit').val(\"$dateofdeposit\");
				\$('#txt-notes').val(\"$notes\");

				\$('#working-form').addClass('hidden');
				\$('#update-form').removeClass('hidden');
                                document.getElementById('donation_type').value = '$donation_type';
                                document.getElementById('category_sel').value = '$category';
			</script>
		";
	} else {

		header('Location:product.php');die('Error while deleting.');		
	}

} else {
	echo('Error while connecting... Please wait while we redirect you');
	//header('Location:../index.php');
	die();
}

?>
