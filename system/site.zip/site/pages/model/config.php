<?php
 
    define('dbHost', 'localhost');
    define('dbUsername', 'nambalem_site');
    define('dbPassword', '@Wagaki1967');
    define('dbName', 'nambalem_site');
  
?>