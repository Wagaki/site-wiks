<?php
require('model.php');
function addCustomer($conn,$data){
	//var_dump($data);
	extract($data);
	
	$sql = "INSERT INTO contact(salutation,salutation_2,address,address_2,city,state,zipcode,country,firstname,lastname,email,prayerpartner,firstname_2,lastname_2,email_2,prayerpartner_2,firstname_3,lastname_3,email_3,prayerpartner_3,firstname_4,lastname_4,email_4,prayerpartner_4,notes,annual) 
			VALUES('$salutation','$salutation_2','$address','$address_2','$city','$state','$zipcode','$country','$firstname','$lastname','$email','$prayerpartner','$firstname_2','$lastname_2','$email_2','$prayerpartner_2','$firstname_3','$lastname_3','$email_3','$prayerpartner_3','$firstname_4','$lastname_4','$email_4','$prayerpartner_4','$notes,'$annual')";
	$result = addData($conn,$sql);
	
	if($result){
		return true;
	}else{
		return false;
	}
}
	
?>