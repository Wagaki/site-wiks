<?php
//session_start();
$position=$_SESSION['position'];
if($position=='director') {
?>
 <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-green">
                          <div class="inner">
                            <h3>Contacts</h3>
                            <p>Add/Edit</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-user"></i>
                          </div>
                          <a href="cust_new.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->

						<div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-red">
                          <div class="inner">
                            <h3>Contact List</h3>
                            <p>View</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-user"></i>
                          </div>
                          <a href="contact.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
                      <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-black">
                          <div class="inner">
                            <h3>Donations</h3>
                            <p>Record</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-usd"></i>
                          </div>
                          <a href="product.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
					  
                      <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-blue">
                          <div class="inner">
                            <h3>Deposits</h3>
                            <p>post/view</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-usd"></i>
                          </div>
                          <a href="stockin.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
					  
					  <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-red">
                          <div class="inner">
                            <h3>Downloads</h3>
                            <p>List</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-envelope"></i>
                          </div>
                          <a href="creditor.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
                      
						 <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-black">
                          <div class="inner">
                            <h3>Acknowledged</h3>
                            <p>View</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-usd"></i>
                          </div>
                          <a href="acknowledge.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
                      <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-green">
                          <div class="inner">
                            <h3>Documents</h3>
                            <p>View</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-usd"></i>
                          </div>
                          <a href="document.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
					  
					  <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-blue">
                          <div class="inner">
                            <h3>Administration</h3>
                            <p>Add/Edit</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-user"></i>
                          </div>
                          <a href="user.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
        
<?php
}
if($position=='user') {
?>

						<div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-red">
                          <div class="inner">
                            <h3>Contact List</h3>
                            <p>View</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-user"></i>
                          </div>
                          <a href="contact.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
                   
			
					  
					  <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-red">
                          <div class="inner">
                            <h3>Downloads</h3>
                            <p>List</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-envelope"></i>
                          </div>
                          <a href="creditor.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
                      
						 <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-black">
                          <div class="inner">
                            <h3>Acknowledged</h3>
                            <p>View</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-usd"></i>
                          </div>
                          <a href="acknowledge.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
                   
                     
<?php
}
if($position=='administration') {
?>
<div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-green">
                          <div class="inner">
                            <h3>Contacts</h3>
                            <p>Add/Edit</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-user"></i>
                          </div>
                          <a href="cust_new.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->

						<div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-red">
                          <div class="inner">
                            <h3>Contact List</h3>
                            <p>View</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-user"></i>
                          </div>
                          <a href="contact.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
                      <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-black">
                          <div class="inner">
                            <h3>Donations</h3>
                            <p>Record</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-usd"></i>
                          </div>
                          <a href="product.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
					  
                      <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-blue">
                          <div class="inner">
                            <h3>Deposits</h3>
                            <p>Post/View</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-usd"></i>
                          </div>
                          <a href="stockin.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
					  
					  <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-red">
                          <div class="inner">
                            <h3>Downloads</h3>
                            <p>List</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-envelope"></i>
                          </div>
                          <a href="creditor.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
                      
						 <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-black">
                          <div class="inner">
                            <h3>Acknowledged</h3>
                            <p>View</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-usd"></i>
                          </div>
                          <a href="acknowledge.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
                      <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-green">
                          <div class="inner">
                            <h3>Documents</h3>
                            <p>View</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-usd"></i>
                          </div>
                          <a href="document.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
					  
					  <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-blue">
                          <div class="inner">
                            <h3>Administration</h3>
                            <p>Add/Edit</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-user"></i>
                          </div>
                          <a href="user.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
<?php
}
if($position=='accountant') {
?>

                      <div class="col-lg-5 col-xs-8">
                        <!-- small box -->
                        <div class="small-box bg-blue">
                          <div class="inner">
                            <h3>Deposits</h3>
                            <p>Post/View</p>
                          </div>
                          <div class="icon" style="margin-top:10px">
                            <i class="glyphicon glyphicon-usd"></i>
                          </div>
                          <a href="stockin.php" class="small-box-footer">
                            Go <i class="fa fa-arrow-circle-right"></i>
                          </a>
                        </div>
                      </div><!-- ./col -->
<?php
}
?>

<?php
//session_start();
if (!isset($_SESSION['username'])) {
//header('Location: workspace_files.php');
}
?>

<?php
//session_start();

if (!isset($_SESSION['mysesi']) && !isset($_SESSION['mytype'])=='admin')
{
 // echo "<script>window.location.assign('login.php')</script>";
}
?>
<?php 
   // session_start();
    if(!isset($_SESSION['position'])){
     // header('Location: index.php');
    }
	?>