<table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
            			<th>Amount</th>
                        <th>Category</th>
                        <th>Donation Type</th>
            			<th>Date of Deposit</th>
                        <th>Fee</th>
						<th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
		
		$query=mysqli_query($con,"select * from donation")or die(mysqli_error());
		$i=1;
		while($row=mysqli_fetch_array($query)){
		$cid=$row['id_code'];
?>
                      <tr>
						<td><?php echo $row['amount'];?></td>
                        <td><?php echo $row['category'];?></td>
                        <td><?php echo $row['donation_type'];?></td>
						<td><?php echo $row['dateofdeposit'];?></td>
           				<td><?php echo $row['paypal_fee'];?></td>
                        <td>
				<a href="<?php echo "add_product.php?".$id=$row['id_code'];?>"><i class="glyphicon glyphicon-plus text-blue"></i></a>
						</td>
                      </tr>
				
              </div>
			  
			  </form>
            </div>
			
        </div><!--end of modal-dialog-->
 </div>
 <!--end of modal-->   	  
                 
<?php $i++;}?>					  
                    </tbody>
                   
                  </table>
                </div><!-- /.box-body -->
 
            </div><!-- /.col -->
			
			
          </div><!-- /.row -->
	 