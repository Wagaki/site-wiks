<form class="form-horizontal" method="post" action="product_add.php" enctype='multipart/form-data'>
        <div class="form-group">
          <label class="control-label col-lg-3" for="name">Id_Code</label>
          <div class="col-lg-8">
            <input type="text" class="form-control" name="id_code" placeholder="">  
          </div>
        </div>
                
        <div class="form-group">
          <label class="control-label col-lg-3" for="name">Salutation</label>
          <div class="col-lg-8">
            <input type="text" class="form-control" name="salutation" placeholder="">  
          </div>
        </div> 
        <div class="form-group">
          <label class="control-label col-lg-3" for="name">Amount</label>
          <div class="col-lg-8">
           <input type="text" class="form-control" name="amount" placeholder="">  
        </div>
        <div class="form-group">
          <label class="control-label col-lg-3" for="name">Category</label>
          <div class="col-lg-8">
              <select class="form-control select2" style="width: 100%;" name="category">
                <?php
            
              $query2=mysqli_query($con,"select * from category order by cat_name")or die(mysqli_error());
                while($row2=mysqli_fetch_array($query2)){
                ?>
                  <option value="<?php echo $row2['cat_id'];?>"><?php echo $row2['cat_name'];?></option>
                <?php }?>
              </select>
          </div>
        </div> 
      <div class="form-group">
          <label class="control-label col-lg-3" for="name">Donation type</label>
          <div class="col-lg-8">
              <select class="form-control select2" style="width: 100%;" name="donation_type">
                <?php
            
              $query2=mysqli_query($con,"select * from donationtype order by don_name")or die(mysqli_error());
                while($row2=mysqli_fetch_array($query2)){
                ?>
                  <option value="<?php echo $row2['don_id'];?>"><?php echo $row2['don_name'];?></option>
                <?php }?>
              </select>
          </div>
        </div> 
       
        <div class="form-group">
          <label class="control-label col-lg-3" for="name">Check_No</label>
          <div class="col-lg-8">
            <input type="text" class="form-control" name="check_no" placeholder="">  
          </div>
        </div> 
		<div class="form-group">
          <label class="control-label col-lg-3" for="name">Date of Check </label>
          <div class="col-lg-8">  
            <input type="date" class="form-control" name="dateofcheck" placeholder="">  
          </div>
        </div> 
		<div class="form-group">
          <label class="control-label col-lg-3" for="name">Date of Deposit</label>
          <div class="col-lg-8">
            <input type="text" class="form-control" name="dateofdeposit" placeholder="">  
          </div>
        </div> 
		<div class="form-group">
          <label class="control-label col-lg-3" for="name">Paypal fee</label>
          <div class="col-lg-8">
            <input type="text" class="form-control"  name="paypal_fee" placeholder="">  
          </div>
        </div> 
		<div class="form-group">
          <label class="control-label col-lg-3" for="name">Donation Year</label>
          <div class="col-lg-8">
            <input type="text" class="form-control" name="donationyear" placeholder="">  
          </div>
        </div> 
		<div class="form-group">
          <label class="control-label col-lg-3" for="name">Posted</label>
          <div class="col-lg-9">
            <input type="radio" name="posted" value="True"> True<br>
			<input type="radio" name="posted" value="False">False<br>				
          </div>
        </div> 
		<div class="form-group">
          <label class="control-label col-lg-3" for="name">Notes</label>
          <div class="col-lg-8">
            <input type="text" class="form-control" name="notes" placeholder="">  
          </div>
        </div> 
		<div class="form-group">
          <label class="control-label col-lg-3" for="name">Last Name</label>
          <div class="col-lg-8">
            <input type="text" class="form-control" name="lastname" placeholder="">  
          </div>
        </div> 
		<div class="form-group">
          <label class="control-label col-lg-3" for="name">Acknowledgedate</label>
          <div class="col-lg-8">
            <input type="date" class="form-control" name="dateforacknowledge" placeholder="">  
          </div>
        </div> 
              </div>
              <div class="modal-footer">
    <button type="submit" class="btn btn-primary">Save changes</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
        </form>