<?php 
session_start();
include('../dist/includes/dbcon.php');
	$id_code = $_POST['id_code'];
	$amount = $_POST['amount'];
	$category = $_POST['category'];
	$donation_type = $_POST['donation_type'];
	$check_no = $_POST['check_no'];
	$dateofcheck = $_POST['dateofcheck'];
	$dateofdeposit= $_POST['dateofdeposit'];
	$notes= $_POST['notes'];
		if ($dateofdeposit != '') {
			$year = substr($dateofdeposit, 0,4);
			$month = substr($dateofdeposit, 5,2);
			$day = substr($dateofdeposit, 8,2);
	
			$dateofdeposit = $month."/".$day."/".$year;
			
		} 
		
		if ($dateofcheck) {
		
			$year = substr($dateofcheck, 0,4);
			$month = substr($dateofcheck, 5,2);
			$day = substr($dateofcheck, 8,2);
			
			$dateofcheck = $month."/".$day."/".$year;
		
		}
			
			mysqli_query($con,"INSERT INTO donation(id_code,amount,category,donation_type,check_no,dateofcheck,dateofdeposit,notes)
			VALUES('$id_code','$amount','$category','$donation_type','$check_no','$dateofcheck','$dateofdeposit','$notes')")or die(mysqli_error($con));

			echo "<script type='text/javascript'>alert('Successfully added new deposit!');</script>";
					  echo "<script>document.location='stockin.php'</script>";  
?>