<?php
include("../dist/includes/dbcon.php");
$id = $_GET['id'];
$result=mysqli_query($con,"DELETE FROM donation WHERE id_code ='$id'")
	or die(mysqli_error());
	
echo "<script>document.location='product.php?'</script>";  
?>