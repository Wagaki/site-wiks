<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;

include('../dist/includes/dbcon.php');
	$id_code = $_POST['id_code'];
	$salutation = $_POST['salutation'];
	$amount = $_POST['amount'];
	$category = $_POST['category'];
	$donation_type = $_POST['donation_type'];
	$check_no= $_POST['check_no'];
	$dateofcheck = $_POST['dateofcheck'];
	$dateofdeposit= $_POST['dateofdeposit'];
	$paypal_fee = $_POST['paypal_fee'];
	$donationyear= $_POST['donationyear'];
	$posted = $_POST['posted'];
	$notes= $_POST['notes'];
	$lastname= $_POST['lastname'];
	$dateforacknowledge=$_POST['dateforacknowledge'];
	
	mysqli_query($con,"update donation set id_code='$id_code',salutation='$salutation',amount='$amount',category='$category',donation_type='$donation_type',check_no='$check_no',dateofcheck='$dateofcheck',dateofdeposit='$dateofdeposit',paypal_fee='$paypal_fee',donationyear='$donationyear',posted='$posted',notes='$notes',lastname='$lastname',dateforacknowledge='$dateforacknowledge' where id_code='$id_code'")or die(mysqli_error($con));
	
	echo "<script type='text/javascript'>alert('Successfully updated donation details!');</script>";
	echo "<script>document.location='product.php'</script>";  

	
?>
