<?php session_start();
if(empty($_SESSION['id'])):
header('Location:../index.php');
endif;

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Documents <?php include('../dist/includes/title.php');?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <!--<link rel="stylesheet" href="../font-awesome/css/font-awesome.min.css">-->
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="../plugins/select2/select2.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
    <style>
      
    </style>
 </head>
  <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
  <body class="hold-transition skin-<?php echo $_SESSION['skin'];?> layout-top-nav">
    <div class="wrapper">
      <?php 
		include('../dist/includes/header.php');
		include('model/crud.php');
		
		$conn = dbconnect();
		
		if ($conn) {
			$sql = "SELECT SUM(amount) AS total FROM donation";
			$results = fetchData($conn,$sql);
			
			if ($results) {
				$results = $results[0];
				$total= $results['total'];
				
			}
			
		}
		
		
      ?>
      <!-- Full Width Column -->
      <div class="content-wrapper">
        <div class="container">
          <!-- Content Header (Page header) -->
          <section class="content-header">
            <h1>
              <a class="btn btn-lg btn-warning" href="home.php">Back</a>
              
            </h1>
            <ol class="breadcrumb">
              <li><a href="home.php"><i class="fa fa-dashboard"></i> Home</a></li>
              <li class="active">Totals</li>
            </ol>
          </section>

          <!-- Main content -->
          <section class="content">
            <div class="row">
	          
			
            <div class="col-xs-12">
              <div class="box box-primary">
    
                <div class="box-header">
                  
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                   <body>
                    <tbody>

              <div class="modal-body">
			  <div class="row">
				  <h5 class="center"><?php if(isset($_GET['status'])){echo $_GET['status'];}?></h5>
				  
					<div class="col-md-12">
					  <div class="panel panel-primary">
					  
						  <div class="panel-heading"><h3 class="text-center">Total Donations</h3></div>
								<div class="panel-body">
									<h2 class='text-center'>$ <?= number_format($total,2,'.',',')?></h2>
								</div>
						  </div>
					</div>
					<div class="col-md-6">
					  <div class="panel panel-primary">
						  <div class="panel-heading"><h3 class="text-center">Total by Category</h3></div>
								<div class="panel-body">
									<form method='POST' action=''>
										<select id="cat" name='cat' >
											<option value='' class='disabled'>Select Category</option>
											<option value='buildings' >Buildings</option>
											<option value='unrestricted'>Unrestricted</option>
											<option value='livestock'>Livestock</option>
											<option value='Wiks_usa Admin'>Wiks_usa Admin</option>
											<option value='Furnishing'>Furnishing</option>
										</select>
										
									</form>
                    <button class='btn btn-primary btn-small' onclick="viewByCat ()">View</button>
									
									<h2 class='text-center'>$ <span id="totCat"></span></h2>
								</div>
						  </div>
					</div>
					
					<div class="col-md-6">
					  <div class="panel panel-primary">
						  <div class="panel-heading"><h3 class="text-center">Total by Date of Deposit</h3></div>
								<div class="panel-body">
									<form method='POST' action=''>
                    <div class="col-md-2">
                      <label>Day</label>
                      <input style="width: 60px;" max="31" id="day" type='number' name='day' placeholder="DD">
                    </div>
                    
                    <div class="col-md-2">
                      <label>Month</label>
                      <input style="width: 60px;" id="month" type='number' name='month' placeholder="MM">
                    </div>
                    
                    <div class="col-md-2">
                      <label>Year</label>
                      <input style="width: 60px;" id="year" type='number' name='year' placeholder="YYYY">
                    </div>
                    
										
									</form>
                    <button class='btn btn-primary btn-small' onclick="viewByDate ()">View</button>
									
									<h2 class='text-center'>$ <span id="totDate"></span></h2>
								</div>
						  </div>
					</div>

			 
				
</body>
            </div>
			
        </div><!--end of modal-dialog-->
 </div>
 <!--end of modal-->   	  
                 
					  
                    </tbody>
                   
                  </table>
                </div><!-- /.box-body -->
 
            </div><!-- /.col -->
			
			
          </div><!-- /.row -->
	 
            
          </section><!-- /.content -->
        </div><!-- /.container -->
      </div><!-- /.content-wrapper -->
      <?php include('../dist/includes/footer.php');?>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script>
      function viewByDate () {

        var day = document.getElementById('day').value;
        var month = document.getElementById('month').value;
        var year = document.getElementById('year').value;

        $('#totDate').text('Fetching... Please wait!');
                          
        $.ajax({url:"add_deposits_totals.php?",
          data: {'day': day, 'month': month, 'year': year},
          type: 'GET',
          success: function (response) {
            
              $('#totDate').text(response);
          }, 
          error: function() {
            alert('Error occured');
          }
        });                          
                          
      } 
      
      function viewByCat () {

        var cat = document.getElementById('cat').value;
      
        $('#totCat').text('Fetching... Please wait!');
                          
        $.ajax({url:"add_deposits_totals.php?",
          data: {'cat': cat,},
          type: 'GET',
          success: function (response) {            

              $('#totCat').text(response);
          }, 
          error: function() {
            alert('Error occured');
          }
        });                          
                          
      }                     
    </script>
    
  </body>
</html>
