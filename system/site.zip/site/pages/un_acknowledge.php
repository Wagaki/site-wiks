<?php
      include('../dist/includes/dbcon.php');
$id = $_GET['cid'];

//$date = date("D d-M-Y");

mysqli_query($con,"UPDATE donation SET dateforacknowledge = '' WHERE id_no = $id")or die(mysqli_error(con));
	
	echo "<script>alert('Successfully Un Acknowledged!');</script>";header("Location:acknowledge.php");
?>