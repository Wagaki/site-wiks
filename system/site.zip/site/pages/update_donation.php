<?php
session_start();
require 'model/crud.php';
if($_SESSION['position'] == 'banker' || $_SESSION['position'] == 'administration'){
} else {
header('Location:../index.php');
die('You are not allowed to acces this page..');
}

$conn = dbconnect();

if ($conn) {
	$id_no = $_POST['user_id'];
	$id_code = $_POST['id-code'];
	$amount= $_POST['amount'];
	$dateofdeposit= $_POST['dateofdeposit'];
	$dateofcheck= $_POST['dateofcheck'];
	$checkno= $_POST['check-no'];
	$category= $_POST['category'];
	$donation_type = $_POST['donation_type'];
	$lastname = $_POST['lastname'];
	$notes = $_POST['notes'];
	$sql = "UPDATE donation SET amount = \"$amount\", category= \"$category\", donation_type = \"$donation_type\", check_no= \"$checkno\", dateofcheck= \"$dateofcheck\", dateofdeposit= \"$dateofdeposit\", notes= \"$notes\" WHERE id_no = $id_no";

	$result = addData($conn, $sql);

	if ($result) {
	
		
			echo"
			<script>
				\$(\"#status\").html(\"<h4 class='text-success text-center'><i class='glyphicon glyphicon-ok'></i> Donation Details Updated Successfully! Do you want to Refresh? <a href='' class='btn btn-warning'><i class='glyphicon glyphicon-refresh'></i> Refresh</a></h4>\");
				\$(\"#btn-update\").html(\"<i class='glyphicon glyphicon-ok'></i> Updated!\");
				\$(\"#idcode-$id_no\").html(\"$id_code\");
				\$(\"#amount-$id_no\").html(\"$amount\");
				\$(\"#cat-$id_no\").html(\"$category\");
				\$(\"#dontype-$id_no\").html(\"$donation_type\");
				\$(\"#checkno-$id_no\").html(\"$checkno\");
				\$(\"#dateofcheck-$id_no\").html(\"$dateofcheck\");
				\$(\"#dateofdepo-$id_no\").html(\"$dateofdeposit\");
				\$(\"#lastname-$id_no\").text(\"$lastname\");
				\$(\"#notes-$id_no\").text(\"$notes\");
				setTimeout(function(){					
					\$(\"#btn-update\").removeClass('disabled');
					\$(\"#btn-update\").text('Save changes');
					\$('#status').html('');
					close_popup('update');
				},2000);
			</script>
			";
		

	} else {

			echo"
			<script>
				\$(\"#btn-update-$id_no\").text('Error while Updating!');
				setTimeout(function(){					
					\$(\"#btn-update-$id_no\").removeClass('disabled');
					\$(\"#btn-update-$id_no\").text('Save changes');
				},1000);
			</script>
			";die();	
	}

} else {
	echo('Error while connecting... Please wait while we redirect you');
	//header('Location:../index.php');die();
}





?>