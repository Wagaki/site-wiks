<div id = "update<?php echo $id;?>" class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
					 <div class="modal-dialog modal-sm">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel2">Edit User Details</h4>
                        </div>
                        <div class="modal-body">
                         <form method = "POST" action = "update_donation.php" id = 'don-update-form-<?=$id?>'> 
						<input type="hidden" name="user_id" value="<?php echo $id;?>">
						<label>ID Code</label>
							<input type="text" name = "id-code" class="form-control" value = "<?php echo $row['id_code'];?>">
						<label>Salutation</label>
							<input type="text" name = "name" class="form-control" value = "<?php echo $row['salutation'];?>" readonly disabled>
						<label>Amount</label>
							<input type="number" name = "amount" class="form-control" value = "<?php echo $row['amount'];?>">
						<label>Check Number</label>
							<input type="text" name = "check-no" class="form-control" value = "<?php echo $row['check_no'];?>">
						<label>Date of Check</label>
							<input type="text" name = "dateofcheck" class="form-control" value = "<?php echo $row['dateofcheck'];?>">
						<label>Date of deposit</label>
							<input type="text" name = "dateofdeposit" class="form-control" value = "<?php echo $row['dateofdeposit'];?>">
						<label for="date">Category</label>
	                                        <div class="input-group col-md-12">
	                                          <select class="form-control select2" style="width: 100%;" name="category">
	                                            <?php
	                                            $query2=mysqli_query($con,"select * from category")or die(mysqli_error());
	                                            while($row2=mysqli_fetch_array($query2)){
	                                            ?>
	                                            <option value="<?php echo $row2['cat_name'];?>"><?php echo $row2['cat_name'];?></option>
	                                            <?php }?>
	                                          </select>							
						<label for="date">Donation Type</label>
	                                          <div class="input-group col-md-12">
	                                            <select class="form-control select2" style="width: 100%;" name="donation_type">
	                                              <?php
	                                              $query2=mysqli_query($con,"select * from donationtype")or die(mysqli_error());
	                                              while($row2=mysqli_fetch_array($query2)){
	                                              ?>
	                                              <option value="<?php echo $row2['don_name'];?>"><?php echo $row2['don_name'];?></option>
	                                              <?php }?>
	                                            </select>
	                                            <label>Fee</label>
							<input type="text" name = "paypal_fee" class="form-control" value = "<?php echo $row['paypal_fee'];?>">
						<label>Last Name</label>
						<input type="text" name = "lastname" class="form-control" ><?php echo $row['lastname'];?></textarea>
							<br/>	
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							<button  name = "update" class="btn btn-primary" id='btn-update-<?=$id?>'>Save changes</button>
						</form>
						</div>
                        <div class="modal-footer">
                          
                        </div>
                      </div>
                    </div>
				</div>
				
				<div id='preview'></div>
				
				<script>
				$("#don-update-form-<?=$id?>").submit(function() {
		        	
			           $("#btn-update-<?=$id?>").text("Updating! Hold on...");
			            $("#btn-update-<?=$id?>").addClass("disabled");
			
			            $.post($(this).attr("action"), $(this).serialize(), function(data) {
			                $("#preview").html(data);
			            });
			
			            
			            return false;
			        });
				
				</script>